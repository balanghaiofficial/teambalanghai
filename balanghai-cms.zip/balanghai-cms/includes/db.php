<?php

    $con = mysqli_connect("localhost", "root", "", "balanghai-cms");

    if (!$con) {
        
        die("Not Connected");
        
  } 

?>